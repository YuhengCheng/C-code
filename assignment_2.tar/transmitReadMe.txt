How to compile:
We require two files to run transmit.c

Compiling the file requires the following to be entered:

gcc -o tran transmit.c bit_manipulation.c

Compiling for the debugger requires the following to be entered:

gcc -g -o tran transmit.c bit_manipulation.c

This program will prompt you for a message that will be converted into short integers. The program will then output the meassage with every char converted to a short integers. The transmit adds parity bits to avoid errors within the decoding process.
