How to compile:
We require two files to run receive.c

Compiling the file requires the following to be entered:

gcc -o tran receive.c bit_manipulation.c

Compiling for the debugger requires the following to be entered:

gcc -g -o tran receive.c bit_manipulation.c

This program will prompt you for a set of short integers. It will then convert the shorts into a message. This program also converts through single errors per byte as it analyzes parity bits within the given short integers.
