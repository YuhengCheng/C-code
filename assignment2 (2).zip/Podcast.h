
#ifndef PODCAST_H
#define PODCAST_H
#include "defs.h"
#include "Episode.h"
#include <iostream>
#include <string>


using namespace std;

class Podcast{

 public:
   //constructor
   Podcast(const string&, const string&);
   Podcast(Podcast&);

   //getters
   const string& getTitle();
   const string& getHost();
   int getNumEpisodes();
   //other
   bool addEpisode(const string&, const string&);
   bool getEpisode(int, Episode**);
   bool lessThan(Podcast&);
   void print();
 private:

   string title;
   string host;
   int numEps;
   Episode **episodes;

};
#endif
