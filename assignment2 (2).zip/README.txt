Created by: Yuheng Cheng
Purpose: a series of files that creates a podcast streaming network

File: Subscriber.cc
Function: creates a subscriber class
	Functions:
		matches(const string& name) = see if the names match 
		
		print() = prints subscriber info
File: Episode.cc
Function: creates an episode class
	Functions:
		play() prints episode info and content
		print() same as play function
File: Podcast.cc
Function: creates a podcast class
	Functions:
		addEpisode(string,string)= add epsiode to podcast class
		 getEpisode(int index, Episode** ep)= look for episode if it exists copy to ep
		 lessThan(Podcast& pod)  = returns bool value based on if this is alphabetically before or after pod.
		 
File: PodArray.cc
Function: array of podcast objects
		

File: Network.cc
Function: Creates a network object
	Function: addPodcast(in podcast: string&, in host: string&): bool = add podcast
	removePodcast(in podcast: string&): bool - remove podcast with given name
	addEpisode(in podcast: string&, in title: string&, in content: string&): bool = get given episode
	addSubscrber(in name: string&, in creditcard: string&): bool = add subscriber to network
	 download(in subscriber: string&, in podcast: string&, out podcast: Podcast**): bool = checks if all the parameters exist and copys the given spot to Podcast**
	 stream(in subscriber: string&, in podcast: string&, in episode: int, out ep: Episode**): bool = checks if all the parameters exist and copys the given spot to Episode**
	 hasSubscriber(in name: string&): bool = see if subscriber is in network class
	 print() = print network info

	
		
