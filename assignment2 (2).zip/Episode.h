
#ifndef EPISODE_H
#define EPISODE_H

#include <iostream>
#include <string>


using namespace std;

class Episode{

	public:
		//constructor
		Episode(const string&, int, const string&, const string&);

    void play();
		void print();


	private:
		string name;
    string podcast;
    string content;
    int number;
};
#endif
