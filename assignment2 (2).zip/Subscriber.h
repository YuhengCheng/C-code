
#ifndef SUBSCRIBER_H
#define SUBSCRIBER_H

#include <iostream>
#include <string>


using namespace std;

class Subscriber{

	public:
		//constructor
		Subscriber(string, string);

    bool matches(const string&);
    void print();


	private:
	   string name;
     string creditcard;
};
#endif
