#ifndef Network_H
#define Network_H
#include "defs.h"
#include "Subscriber.h"
#include "Podcast.h"
#include "PodArray.h"
#include <iostream>
#include <string>


using namespace std;

class Network{
public:
  //constructor
  Network(const string&);
  ~Network();
  //getters
  bool getPodcast (const string&, Podcast**);
  bool hasSubscriber(const string&, Subscriber**);

  //add and remove
  bool addPodcast(const string&,const string&);
  bool removePodcast(const string&);
  bool addEpisode(const string&, const string &, const string &);
  bool addSubscriber(const string&, const string&);
  //client services
  bool download(const string&, const string&, Podcast**);
  bool stream(const string&, const string&,int, Episode**);
  bool hasSubscriber(const string&);
  void print();
private:

  string networkName;
  PodArray *podPoint;
  Subscriber *subscribers[MAX_SUBS];
  int numSubs;
};
#endif
