#ifndef CLIENT_H
#define CLIENT_H
#include "defs.h"
#include "Network.h"

#include <iostream>
#include <string>


using namespace std;
class Client{

public:
  Client(const string&);
  void download(Network*, const string&);
  void stream(Network*, const string&, int);
  void playLocal(const string&,int);
  void print();
private:
  string clientName;
  PodArray *podPoint;
};
#endif
