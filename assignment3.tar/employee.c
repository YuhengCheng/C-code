#include "employee.h"
#include "stdio.h"

void printEmployee(PersonRec person)

{
	char str[33];
	sprintf(str,"%s %s", person.firstName,person.familyName);
	printf("%-33sdept:%2d salary %8.2f position %2d years of service: %2d salary to date: %10.2f\n", str,person.emp.department,person.emp.salary,person.emp.position,person.emp.yearsService,person.emp.salary*person.emp.yearsService);
    

}

void printEmployees(PersonRec *person, int numRecords)
{
	int i = 0;
	while (i < numRecords) {
	    if(person->emplyeeOrPatient== EMPLOYEE_TYPE){
	    printEmployee(*person);
	    }
		person++;
		i++;
	}

}
void employeePositionSummary(PersonRec *person, int numRecords, int empPos){
 
    int i = 0;
    float totalSal =0;
    int empCount =0;
	while (i < numRecords) {
	    if(person->emplyeeOrPatient== EMPLOYEE_TYPE&&person->emp.position == empPos ){
	    totalSal +=person->emp.salary;
	    empCount += 1;
	    }
		person++;
		i++;
	}
	
	printf("position[%d] - employees:%2d total salary:%8.2f average salary:%7.2f\n",i, empCount, totalSal,totalSal/empCount);





}

void printEmployeesSummary(PersonRec *person, int numRecords)
{

    int i = 0;
    int j;
    float totalSal =0;
    int empCount =0;
	while (i < numRecords) {
	    if(person->emplyeeOrPatient== EMPLOYEE_TYPE){
	    totalSal += person->emp.salary;
	    empCount += 1;
	    }
		person++;
		i++;
	}
	printf("Total number of employees:%3d total salary:%8.2f average salary:%7.2f\n",empCount, totalSal,totalSal/empCount);	
    for(j = 0; j <4; j++){
    	employeePositionSummary(person, numRecords, j);
    }
    

}


