

#include "stdio.h"
#include "stdlib.h"
#include "struct.h"
#include "string.h"
#include "populateRecords.h"
#include "patient.h"
#include "employee.h"

#define NUM_RECORDS 20
int menu(){
	int check = 0;
	int choice[1];
	printf("Please enter the number to go to the corresponding menu option\n");
	printf("1. Print all employees\n");
	printf("2. Search for all patients by Family Name\n");
	printf("3. Summary of Employees Data\n");
	printf("4. Summary of Patients data\n");
	printf("5. Size of structures (PersonRec, PatientRec and Employee Rec\n");
	printf("0. Quit\n");
	while(check == 0){
		printf("Please enter your choice\n");
		scanf("%d", choice);
		if(0<=*choice && *choice <= 5){
		    return *choice;
		}else{
		    printf("Please enter 1 value from 0-5\n");
		}
	}


}
//purpose creates a database of patients and employees at the hospital, provides a variety of different ways to present the data
//Version 1: created by Yuheng Cheng
// development date Nov 11, 2021

//main function is run when user runs through command line
int main(int argc, char *argv[])
{
    //initialize variables to be used
    struct person *person = NULL;
    int numRecords = 0;         // number of records to be created
	char rc = 0;
    int check =0;
    char *choice;
    int runCheck =0;

  
      // if number of records is not given then insruct the user what is required.
	if(argc <2){
	printf("Please enter a number of records to create after program name \n Invoking the program: program name number_of_records");
	exit(0);
	printf("For Example: hospital 37");
	}else if(atoi(argv[1])<1){
	    printf("Please enter a positive integer to create records");
	    exit(0);
	    //pass the command line arguement
	}else{
	numRecords = atoi(argv[1]);
	}
    //dynamically allocate the array needed
    person = malloc( numRecords*sizeof(struct person));

    // populating the array person with data of patients and employees
    populateRecords(person, numRecords);

    // add code here
    while(runCheck ==0){
    //switch case for menu options. Do not input anything outside of these values
    switch(menu())
    {
    case 1:
    	printEmployees(person, numRecords);
    	break;
    case 2:
    	searchPatients(person, numRecords);
    	break;
    case 3:
    	printEmployeesSummary(person, numRecords);
    	break;
    case 4:
    	printPatientSummary(person,numRecords)
    	break;
    case 5:
    	printf("Size of structures\n");
    	printf("Size of PersonRec = %ld\n",sizeof(PersonRec));
	printf("Size of EmployeeRec = %ld\n",sizeof(EmployeeRec));
	printf("Size of PatientRec = %ld\n",sizeof(PatientRec));
	break;
	
    case 0:
    	//check if user wants to quit
    	while(check == 0){
		printf("Are you sure you want quit? y/n");
		scanf("%c", choice);
		//if quit 
		if(*choice == "y"|| *choice == "Y"){
		//free the memory
		    free(person);
		    //quit and return 0
		    exit(0);
		}else if(*choice == "n"|| *choice == "N"){
		    break;
		}else{
		   printf("Please enter y or n");
		}
	}
	break;
    }default:
    printf("Error value is incorrect);
    }
    free(person);

    
    return 0;
}




