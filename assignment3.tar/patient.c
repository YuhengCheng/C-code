

#include "string.h"
#include "stdio.h"
#include "patient.h"

/********************************************************************/
void printPatient(PersonRec person)

{
     //init char
    char str[33];
	sprintf(str,"%s %s", person.firstName,person.familyName);
	//print value
	printf("%-33sdept: %d daily cost: %d severity: %d days in hospital: %d cost to date: %d\n", str,person.patient.department,person.patient.dailyCost,person.patient.severity,person.patient.numDaysInHospital,person.patient.dailyCost*person.patient.numDaysInHospital);

}

/********************************************************************/
void printPatients(PersonRec *person, int numRecords)
{
   //iterate through program to print
   int i = 0;
	while (i < numRecords) {
	    if(person->emplyeeOrPatient== PATIENT_TYPE){
	    printPatient(*person);
	    }
		person++;
		i++;
	}

}


/********************************************************************/
void printPatientSummary(PersonRec *person, int numRecords)
{
    int j = 0;
    int i = 1;
    while(i < 7){
    float totalCost =0;
    float dailyTotal;
    int pCount =0;
	while (j < numRecords) {
	    if(person->emplyeeOrPatient== EMPLOYEE_TYPE&&person->patient.department == j ){
	    totalCost +=person->patient.dailyCost*person->patient.numDaysInHospital;
	    dailyTotal += person->patient.dailyCost;
	    pCount += 1;
	    }
		person++;
		j++;
	}
	
	printf("Department[%d] - employees:%3d cost to date:%6.2f daily cost:%6.2f, average dailycost per patient%6.2f\n",i, pCount, totalCost,dailyTotal,dailyTotal/pCount);
    	
    }

}


/********************************************************************/
void searchPatients(PersonRec *person, int numRecords)

{
    char *choice;
    printf("Please enter patient family name: ");
    scanf("%s", choice);

    int i = 0;
	while (i < numRecords) {
	    if(person->emplyeeOrPatient== PATIENT_TYPE && 0 == (strcmp(person->familyName, choice))){
	    printPatient(*person);
	    }
		person++;
		i++;
	}

}
