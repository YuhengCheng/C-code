// files is arrays.c
/* The program in this file computes an average gpa 
grade of a student

 

 Revisions:
 19/9/2021 - Initial version   DN
 04/10/2021 - Final Version Yuheng Cheng
 */


/*************************************************************************/

/* Include files */
#include "stdio.h"
#include "stdlib.h"



/*************************************************************************/

/* DEFINE */
#define ARR_SIZE  20


/**********************************************************************/

/* PROTOTYPES */

int populateArray(int numbers[], int maxArrSize, int* arrSize);
int removeValues(int minValue, int arr[], int maxArrSize, int *arrSize);
int printArray(int numbers[], int arrSize);


/**********************************************************************/




int main(int argc, char* argv[])
{
    //create all the variables necessary
    int gpa[ARR_SIZE];
    int arrSize;
    int rc;
    int i;
    int minValue;
    float total =0;
    float average;
    // populate the array with numbers
    populateArray(gpa, ARR_SIZE, &arrSize);

    // printf the array
    printf("the courses grades are:\n");
    printArray(gpa, arrSize);

    // compute the average gpa
    //add code
    for(i = 0; i < arrSize; i++){
    	total += gpa[i];
    }
    average = total/arrSize;
    
    // print the number of courses and the average gpa
    
    printf("The number of  courses = %d, GPA is = %.2f\n",arrSize, average);


    // remove low grades
    printf("removing all gpa elements smaller than 7 \n");
    removeValues(7, gpa, ARR_SIZE, &arrSize);

    // print remining grades
    printf("the grades with grades >= 7 are:\n");
    printArray(gpa, arrSize);

    // compute the average gpa
    total = 0;
    for(i = 0; i < arrSize; i++){
    	total += gpa[i];
    }
    average = total/arrSize;
    
    // print the number of courses and the average gpa
    printf("The number of  courses = %d, GPA is = %.2f\n",arrSize, average);

    return(0);
    

  
}






/************************************************************************/

/* Purpose: populate the array with random in the given range of numbers until the array is full or the user's input is -1


input:
arr -  array of integers
maxArrSize - the numbers of elements in the array

output:
arr - the modified array
arrSize - the number of elements in the array after the array was populated

Assumptions:
the user is a friendly user - there is no need to check input or clear the buffer
*/
int populateArray(int arr[], int maxArrSize, int *arrSize)
{

     //create a temporary array
     int tempArr[maxArrSize];
     //create index for iteration
     int i;
     //create temporary user input to check
     int check;
    //a for loop to iterate through every index and populate them
    for (i=0; i< maxArrSize; i++){
    	//scan for input
    	scanf("%d", &check);
    	//check if input was -1
    	if (check == -1){
    	//set size
    	*arrSize = i;
    	/break the loop
    	break;
    	}else{
    	//set the index
    	tempArr[i] = check;
    	*arrSize = i;
    	}
    
    }
    //write temporary array to gpa array
    for (i=0; i< maxArrSize; i++){
    	arr[i] = tempArr[i];
    }
    
    return(0);
}




/************************************************************************/

/*
Purpose: remove all number that are smaller than the given min value.
For example if minValue is 5 then all number in the array that are smaller than 5 are 
to be removed from the array and the array size needs to be adjusted.

input: 
minValue - minimum value, remove all values below this number
arr[] - array of all gpas
maxArrSize - maximum size of array
arrSize - acutal size of array


output:

return
0 

*/


int removeValues(int minValue, int arr[], int maxArrSize, int *arrSize)
{
   //create variable for counters
   int i = 0, j;
   //create a temporary size var
   int size = *arrSize;
   //while loop
   while( i < size ){\
   	//check if current element is less than min value
   	if (arr[i] < minValue){
   	  //change values
   	  for (j = i; j < (size  - 1) ;j++)
                arr[j] = arr[j+1];
             //decrease size var
             size --;
        //incrementthe counter
   	}else{
   	i++;}
   
   
   }
  //set actual size variable to temp var
  *arrSize = size;
  return 0;
}



/************************************************************************/

/*
Purpose: prints the array.  All grades should appear in one row.


input:
arr - the array of integers
arrSize - the numbers of elements in the array


return
0 
*/


int printArray(int arr[], int arrSize)
{
    //create variable for a counter
    int i;
    //iterate through the array to print all of the grades
    for(i = 0; i < arrSize; i++){
    	if (i == arrSize -1){
    	   printf("%d \n", arr[i]);
    	}else{
    	   printf("%d, ", arr[i]);	
    	}
    }
    
    
    
    

}




