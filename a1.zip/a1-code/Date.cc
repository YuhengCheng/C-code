
#include "Date.h"
//default constructor
Date::Date(){
	setDate(1901,1,1,0,0);
}
//constructor with arguements
Date::Date(int y, int m, int d,int h, int dur){
	setDate(y,m,d,h,dur);
}

//copy constructor
Date::Date(Date& d){
	setDate(d);
}


//setters
void Date::setDay(int d){
	int max = getMaxDay();
	if (d>max) d=max;
	if (d<1) d=1;
	day = d;
}

void Date::setMonth(int m){
	if (m > 12) m = 12;
	if (m < 1) m = 1;
	month = m;
}

void Date::setYear(int y){
	if (y < 1901) y = 1901;
	year = y;
}
void Date::setHour(int h){
	if( h<0) h = 0;
	if (h>23) h= 23;
	hour =h;
}
void Date::setDuration(int d){
	if( d<0) duration = 0;
	else if (d>GLOBAL_CONST_VAR) duration = 3;
	else duration = d;
}


void Date::setDate(int y, int m, int d, int h, int dur){
	setMonth(m);
	setDay(d);
	setYear(y);
	setHour(h);
	setDuration(dur);
}

void Date::setDate(Date& d){
	setDate(d.year, d.month, d.day, d.hour,d.duration);
}


//getters
int Date::getDay(){ return day; }
int Date::getMonth(){ return month; }
int Date::getYear(){ return year; }
int Date::getHour(){return hour;}
int Date::getDuration(){return duration;}
const string& Date::getMonthName(){return months[month-1];}


//other
bool Date::overlaps(Date& d){
	//check year
	if (year == d.year){
		//check month
		if (month == d.month){
			//check day
			if (day == d.day){
				//loop through duration
				for(int i = 0; i<=duration; i++){
					if(hour>d.hour){
						return false;
					}
					else if(this->getHour() + i > d.hour){
						return true;
					}else if(hour + i > 23){
						return false;
					}
				}

					return false;

				}else{
					return false;
				}
				}else{
				return false;
			}
			}else{
				return false;
			}
		}



bool Date::lessThan(Date& d){
	//check year
	if (year == d.year){
		//check month
		if (month == d.month){
			//check day
			if (day == d.day){
				return hour <d.hour;
				}else{
				return day < d.day;
			}
			}else{
				return month  < d.month;
			}
		}else{
			return year < d.year;
	}
}

void Date::print(){
	cout << getHour()<< " "<< getDuration() << " "<<getMonthName()<<" "<<getDay()<<", "<<getYear()<<endl;
}

int Date::getMaxDay(){
	switch(getMonth()){
		case 4:
		case 6:
		case 9:
		case 11: 			return 30;
		case 2:				return 28;
		default:			return 31;
	}
}
