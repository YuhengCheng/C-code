#ifndef LIBRARY_H
#define LIBRARY_H
#include "Student.h"
#include "Date.h"
#include "Room.h"
#include "Reservation.h"
const int MAX_ARRAY_SIZE = 50;
#include <iostream>
#include <string>

using namespace std;

class Library{
	public:

		//constructor
		Library();
		Library(Student* [], Room* [], Reservation* []);
    ~Library();


		//other
		//functions
    bool addStudent(const string&name, const string& number);
    bool addRoom(const string&name, int capacity = 1, int computers= 0, bool whiteboard= false);
    bool getStudent(const string& name, Student** student);
    bool getRoom(const string& roomName, Room** room);
    bool isFree(const string& roomName, Date& date);
		bool makeReservation(const string& student, const string& room, Date&);

	private:

		//variables
    Student **students ;
    Room **rooms ;
    Reservation **reservations ;
    int sSize;
    int rSize;
    int resSize;

  };
  #endif
