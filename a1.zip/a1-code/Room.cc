#include "Room.h"
#include <string>
#include <iostream>
using namespace std;

Room::Room(){
	setRoom("Science Class", 1 , 0 , false);
}

Room::Room(string n, int cp, int cmp,bool wb){
	setRoom(n,cp,cmp, wb);
}

Room::Room(const Room& r){
	setRoom(r.name,r.capacity,r.computers, r.whiteboard);

}


//setters
void Room::setName(string n){
	name = n;
}

void Room::setCapacity(int cp){
	capacity = cp;
}
void Room::setComputers(int cmp){
  computers = cmp;
}

void Room::setWhiteboard(bool wb){
  whiteboard = wb;
}


void Room::setRoom(string n, int cp, int cmp, bool wb){
  setName(n);
	setCapacity(cp);
  setComputers(cmp);
  setWhiteboard(wb);
}

//getters
string Room::getName(){ return name; }
int Room::getCapacity(){ return capacity; }
int Room::getComputers(){return computers;}
bool Room::hasWhiteboard(){return whiteboard;}



//other
bool meetsCriteria(int cp,int cmp, bool wb){
  return true;

}
bool Room::lessThan(Room& r){
		if (name.compare(r.name) < 0){
			return true;
	}else{
		return false;
	}
}
bool Room::meetsCriteria(int c, int comp = 0, bool wb = false){
	if(c <= capacity){
		if(comp<= computers){
			if(wb== false|| wb == whiteboard){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}else{
		return false;

}
}

void Room::print(){
	cout << getName()<<" "<<getCapacity()<<" "<<getComputers()<<" "<<hasWhiteboard()<<endl;
}
