#include "Student.h"
#include <string>
#include <iostream>
using namespace std;

Student::Student(){
	setStudent("John Doe","1111111");
}

Student::Student(string nm, string nb){
	setStudent(nm,nb);
}

Student:: Student(const Student& s){
	setStudent(s.name,s.number);

}


//setters
void Student::setName(string n){
	name = n;
}

void Student::setNumber(string n){
	number = n;

}
void Student::setStudent(string nm, string nb){
	setName(nm);
	setNumber(nb);

}

//getters
string Student::getName(){ return name; }
string Student::getNumber(){ return number; }



//other

bool Student::lessThan(Student& s){
		if (number.compare(s.number) < 0){
			return true;
	}else{
		return false;
	}
}

void Student::print(){
	cout << getName()<<" "<<getNumber()<<endl;
}
