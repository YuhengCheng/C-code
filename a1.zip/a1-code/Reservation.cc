#include "Reservation.h"
#include "Student.h"
#include "Date.h"
#include "Room.h"
#include <string>
#include <iostream>
using namespace std;

//constructor

Reservation::Reservation(Student* s, Room* r, Date& d){
  student = s;
  room = r;
  date.Date::setDate(d);

}


//getters
Student* Reservation::getStudent(){return student;};
Room* Reservation::getRoom(){return room;};
Date Reservation::getDate(){return date;};

//other
bool Reservation::lessThan(Reservation& res){
  return this->date.Date::lessThan(res.date);
}
bool Reservation::overlaps(const string& r, Date& d){
  if(room->getName().compare(r)== 0){
    return this->date.overlaps(d);
  }else{

    return false;
  }
}
void Reservation::print(){
  cout<<"Room " <<this->getRoom()->getName() << " is rented by "<< this->getStudent()->getName()<< " on " <<date.getHour()<< " "<< date.getDuration() << " "<<date.getMonthName()<<" "<<date.getDay()<<", "<<date.getYear()<<endl;
}
