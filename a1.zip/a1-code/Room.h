#ifndef ROOM_H
#define ROOM_H
#include <string>
#include <iostream>
using namespace std;
class Room{


  public:
    //constructor
    Room();
    Room(string name, int capacity, int computers,bool whiteboard);
    Room(const Room& r);
    //setters
    void setName(string);
    void setCapacity(int);
    void setComputers(int);
    void setWhiteboard(bool);
    void setRoom(string name, int capacity, int computers,bool whiteboard);
    string getName();
    int getCapacity();
    int getComputers();
    bool hasWhiteboard();

    //other
    bool meetsCriteria(int capacity, int computers, bool whiteboard);
    void print();
    bool lessThan(Room &r); 

  private:
    string name;
    int capacity;
    int computers;
    bool whiteboard;


};
#endif
