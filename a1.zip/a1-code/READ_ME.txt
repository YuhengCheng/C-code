Created by: Yuheng Cheng
Purpose: a series of files that creates a reservation system using date, student and room classes

File: Student.cc
Function: creates a student class comprised of a student name and number

	Functions:
		lessThan(student)= returns a boolean value based on if this->name comes before student-> 		name or not
		
		print() = prints student information to screen
File: Room.cc
Function: creates a room class comprised of room name, capacity, # f computers and if it has a whiteboard or not
	Functions:
		lessThan(room)= returns a boolean value based on if this->name comes before room-> 			name or not
		
		meetsCriteria(int capacity, int computers, bool whiteboard)= returns a boolean value based 
		on if this meets the criteria given as arguements to the function
		
		print() = prints room information to screen
File: Date.cc
Function: creates a date class comprised of year,month,day,hour and duration
	Functions:
		overlaps(&Date)= returns a boolean value based on if the two dates overlap or not
		
		lessThan(&Date) = returns a boolean value based on if this date is earlier than the date given in the 			argument
		
		print() = prints date information to screen

File: Reservation.cc
Function: creates a reservation class to comprised of a student room and date objects
	Functions:
		overlaps(&reservation)= checks if the date at this->date and resrvation->date overlap
		
		lessThan(&reservation) = returns a boolean value based on if this date is earlier than the date given 			in the 	argument
		

File: Library.cc
Function: creates a library class comprised of 3 pointer arrays of 3 types of objects. One array of student pointers, one array of room pointers and 1 array of reservation pointers. Library.cc is also respobsible for allocating and deallocating the various arrays.

Function: creates a reservation class to comprised of a student room and date objects
	Functions:
		addStudent(const string& name, const string& number) = check if there is space in student[] if not return false if true add a new student object to this.students[] and return true
		
		addRoom(name, capacity, computers, whiteboard) = check if there is space in room[] if not return false if true add a new room object to this.rooms[] using the given arguements and return true
		
		isFree(const string& room, Date&) = check if the given room is free at the given date return true if it is free false if not.
		
		makeReservation(const string& student, const string& room, Date&) = make a reservation class with the arguements after checking if there is space in the resrvtaions[] array. If not return false if true create a new reservation object with the given arguements
