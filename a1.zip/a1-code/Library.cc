/*inclusions*/
#include "Student.h"
#include "Date.h"
#include "Room.h"
#include "Reservation.h"
#include "Library.h"
#include <iostream>
#include <string>
using namespace std;




		//constructor
		Library::Library(){
      students = new Student*[0];

      rooms = new Room*[0];

      reservations = new Reservation*[0];
			sSize = 0;
			rSize = 0;
			resSize = 0;


    }
		Library::Library(Student* s[], Room* r[], Reservation* rs[]){
    sSize= sizeof(*s)/sizeof(*s[0]);
    students = new Student*[sizeof(*s)/sizeof(*s[0])];
    for(int i =0; i < sizeof(*s)/sizeof(*s[0]); i++){
      students[i] = s[i];
    }
    rSize = sizeof(*r)/sizeof(*r[0]);
    rooms = new Room*[rSize];
    for(int i =0; i < rSize; i++){
      rooms[i] = r[i];
    }
    resSize =sizeof(*rs)/sizeof(*rs[0]);
    reservations = new Reservation*[resSize];
    for(int i =0; i < sizeof(*rs)/sizeof(*rs[0]); i++){
      reservations[i] = rs[i];
    }


  }
    //deconstructor
    Library::~Library(){
      delete[] students;
      delete[] rooms;
      delete[] reservations;
    }

		//functions
    bool Library::addStudent(const string& name, const string& number){
      if(sSize<50){
        int tempsize = sSize + 1;
        Student** tempArr = new Student*[tempsize];
				if(sSize != 0){
        for(int i =0; i < sSize; i++){
          tempArr[i] = students[i];
        }
			}

        delete [] students;
        sSize = tempsize;

        students = tempArr;

        this->students[sSize-1] = new Student(name,number);
        return true;
      }
      return false;
    }

    bool Library::addRoom(const string&name, int capacity, int computers, bool whiteboard){
      if(rSize<50){
        int tempsize = rSize + 1;
        Room** tempArr = new Room*[tempsize];
				if(rSize != 0){
        for(int i =0; i < rSize; i++){
          tempArr[i] = rooms[i];
        }
			}
        delete [] rooms;
        rSize = tempsize;
        rooms = tempArr;
        this->rooms[rSize-1]= new Room(name,capacity, computers, whiteboard);
        return true;
      }
      return false;
    }
    bool Library::getStudent(const string& name, Student** student){
      for(int i =0; i < sSize; i++){
        if(this->students[i]->getName().compare(name)==0){
          student = &students[i];
          return true;
        }
      }
      return false;
    }
    bool Library::getRoom(const string& roomName, Room** room){
      for(int i =0; i < rSize; i++){
        if(this->rooms[i]->getName().compare(roomName)==0){
          room = &rooms[i];
          return true;
        }
      }
      return false;
    }
    bool Library::isFree(const string& roomName, Date& date){
      for(int i =0; i < rSize; i++){
        if(rooms[i]->getName().compare(roomName)==0 && resSize != 0){
          for(int j =0; j < resSize; j++){
            if(!(this->reservations[j]->overlaps(roomName,date))){

              return true;
            }
          }
        }else if(rooms[i]->getName().compare(roomName)==0 && resSize == 0){
					return true;
				}
      }
      return false;


    }
		bool Library::makeReservation(const string& s, const string& r, Date& d){

			for(int i =0; i < rSize; i++){
        if(this->rooms[i]->getName().compare(r)==0){
					for(int j =0; j < sSize; j++){

		        if(this->students[j]->getName().compare(s)==0){

		          if(isFree(r,d)&& resSize <MAX_ARRAY_SIZE){

								int tempsize = rSize + 1;
								Reservation** tempArr = new Reservation*[tempsize];
								if(resSize!= 0){

				        for(int k =0; k < resSize; k++){
				          tempArr[k] = reservations[k];
				        }
							}



								delete [] reservations;
								resSize = tempsize;
								reservations = tempArr;
				        this->reservations[resSize-1] = new Reservation(students[j],rooms[i],d);
								return true;

							}return false;

		        }
		      }
					return false;


        }
      }
			return false;
		}

		//variables
