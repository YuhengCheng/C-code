#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <iostream>
using namespace std;
class Student{


  public:
    //constructor
    Student();
    Student(string name, string number);
    Student(const Student& s);
    //setters
    void setName(string);
    void setNumber(string);
    void setStudent(string name, string number);
    //getters
    string getName();
		string getNumber();

    //other
    bool lessThan(Student&s);
    void print();

  private:
    string name;
    string number;

};
#endif
