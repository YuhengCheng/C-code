#ifndef PART_H
#define PART_H
#include "Date.h"
#include <string>
#include <iostream>
#include "defs.h"
class Part{
public:
  friend ostream& operator<<(ostream&, const Part&);
  Part(const string&);
  virtual ~Part();
  string getName() const;
  void addFlightHours(int);
  void install(Date&);
  virtual bool inspection(Date&) = 0;

  protected:
  string name;
  Date installationDate;
  int flighthours;
};

class FH_Part:public  virtual  Part{
  friend ostream& operator<<(ostream&, const FH_Part&);
public:
  FH_Part(const string&, int);
  virtual bool inspection(Date&);
  protected:
  int fh_inspect;
};
class IT_Part: public virtual Part{
  friend ostream& operator<<(ostream&, const IT_Part&);
public:
  IT_Part(const string&, int);
  virtual bool inspection(Date&);
  protected:
  int it_inspect;
};

class FHIT_Part: public FH_Part, public IT_Part{
  friend ostream& operator<<(ostream&, const FHIT_Part&);
public:
  FHIT_Part(const string&, int, int);
  virtual bool inspection(Date&);
};

#endif
