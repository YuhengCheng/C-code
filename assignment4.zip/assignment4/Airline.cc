#include "Airline.h"

Airline::Airline(const string& n){
  name = n;

}
Airline::~Airline(){
  for(int i = 0; i<aParts.getSize(); i++){
    delete[] aParts[i];
  }
  aParts.~Array();
  for(int i = 0; i<aircrafts.getSize(); i++){
    delete[] aircrafts[i];
  }
  aircrafts.~Array();
}

Part Airline::getPart(const string&n){
  for(int i = 0; i<aParts.getSize(); i++){
    if(aParts[i]->getName()== n){
      return *aParts[i];
    }
  }

}

Aircraft Airline::getAircraft(const string&n){
  for(int i = 0; i<aircrafts.getSize(); i++){
    if(aircrafts[i]->getRegistration()== n){
      return *aircrafts[i];
    }
  }

}

void Airline::addAircraft(const string& t, const string& r){
  aircrafts.add(new Aircraft(t,r));
}

void Airline::addPart(const string& part, int fh_inspect, int it_inspect){
  if(fh_inspect> 0&& it_inspect>0){
    aParts.add(new FHIT_Part(part,fh_inspect,it_inspect));
  }
  else if(fh_inspect== 0&& it_inspect>0){
    aParts.add(new IT_Part(part,it_inspect));
  }
  else if(fh_inspect> 0&& it_inspect==0){
    aParts.add(new FH_Part(part,fh_inspect));
  }
}
void Airline::takeFlight(const string& reg, int hour){
  for(int i = 0; i<aircrafts.getSize(); i++){
    if(aircrafts[i]->getRegistration()== reg){
      aircrafts[i]->takeFlight(hour);
    }
  }
  cout<<"Airplane cannot be found"<<endl;
}
void Airline::printAircraft(){
  cout<<aircrafts<<endl;
}

void Airline::printParts(){
  cout<<aParts<<endl;
}

void Airline::inspectionReport(const string& reg, Date& d){
  for(int i = 0; i<aircrafts.getSize(); i++){
    if(aircrafts[i]->getRegistration()== reg){
      cout<<aircrafts[i]<<" "<<endl;
      Array<Part*> tempArr ;
      aircrafts[i]->inspectionReport(d,tempArr);
      cout<<tempArr;
      return;
    }
  }
  cout<<"Airplane not found"<<endl;
}

bool Airline::install(const string& reg, const string& part, Date& d){
  for(int i = 0; i<aircrafts.getSize(); i++){
    if(aircrafts[i]->getRegistration()== reg){
      for(int j = 0; j<aParts.getSize();j++){
          if(aParts[j]->getName()== part){
            aircrafts[i]->install(aParts[j],d);
            return true;
          }
      }
      cout<<"part not found"<<endl;
      return false;

    }
  }
  cout<<"Airplane not found"<<endl;
  return false;
}
