#include "Part.h"
ostream& operator<<(ostream& ost, const Part& t){
  ost<<t.getName()<<"flighthours"<< t.flighthours;
  return ost;
}
  Part:: Part(const string& n){
    name = n;
    flighthours = 0;
  }
  Part::~Part(){}
  string Part::getName() const{
    return name;
  }
  void Part:: addFlightHours(int h){
    flighthours+= h;
  }
  void Part::install(Date& d){
    installationDate = d;
  }

  ostream& operator<<(ostream& ost, const FH_Part& t){
    ost<<t.getName()<<"flighthours"<< t.flighthours;
    return ost;
  }

  FH_Part::FH_Part(const string& n, int h):Part(n){
    fh_inspect = h;
  }

  bool FH_Part::inspection(Date& d){
    if (flighthours >= fh_inspect){
      return true;
    }
    return false;
  }


  ostream& operator<<(ostream& ost, const IT_Part& t){
    ost<<t.getName()<<"flighthours"<< t.flighthours;
    return ost;
  }

  IT_Part::IT_Part(const string& n, int h):Part(n){
    it_inspect = h;
  }


  bool IT_Part::inspection(Date& d){

    if (d.toDays()-installationDate.toDays() >= it_inspect){
      return true;
    }
    return false;
  }


  ostream& operator<<(ostream& ost, const FHIT_Part& t){
    ost<<t.getName()<<"flighthours"<< t.flighthours;
    return ost;
  }

  FHIT_Part::FHIT_Part(const string& n, int fh, int ih): Part(n),FH_Part(n,fh), IT_Part(n,ih){

  }

  bool FHIT_Part::inspection(Date& d){

    if (FH_Part::inspection(d)|| IT_Part::inspection(d)){
      return true;
    }
    return false;
  }
