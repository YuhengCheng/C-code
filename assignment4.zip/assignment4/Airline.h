#ifndef AIRLINE_H
#define AIRLINE_H

#include "Aircraft.h"

class Airline{
public:
  Airline(const string&);
  ~Airline();
  void addAircraft(const string&, const string&);
  void addPart(const string&, int , int );
  void takeFlight(const string&, int);
  void printAircraft();
  void printParts();
  void inspectionReport(const string&, Date&);
  bool install(const string&, const string&, Date&);
private:
  string name;
  Array<Part*> aParts;
  Array<Aircraft*> aircrafts;
  Aircraft getAircraft(const string&);
  Part getPart(const string&);
};
  #endif
