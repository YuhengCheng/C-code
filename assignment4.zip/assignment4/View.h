#ifndef VIEW_H
#define VIEW_H

#include <iostream>
#include <string>
#include "Aircraft.h"

using namespace std;


class View
{
  public:
    void showMenu(int&);
  
};

#endif
