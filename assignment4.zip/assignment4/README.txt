Created by: Yuheng Cheng
Student Number 101189894
Purpose: a series of files that creates airplanes and simulates an airline system

File: Part.cc
Class Part
Function: virtual base class of FH_Part and IT_Part
	Functions:
	getName() gets name of Part
	void addFlightHours(int) adds int to flight hours
	install update the installationDate
	
	inspection pure virtual function
		
			
		

Class FH_Part
Function: creates a floght hours part


	inspection() return true if the flightHours is greater than fh_inspect variable
	
Class IT_Part
Function: creates a floght hours part


	inspection() return true if the flightHours is greater than it_inspect variable
	
Class FHIT_Part Class

	inspection() return true if either FH_Part::inespection or IT_Part::inspection return true or false otherwise
		
File: Array.h
creates a template class for an array for any data type.

File:Aircraft.cc

	getRegistration() get registration
	void install(Part*, Date&). Add the given Part* to the Array. Call the appropriate member function
	on the Part object to install the part.
	void takeFlight(int hours). Update the flightHours member variable by adding the supplied number of hours. This should also update the flighthours of all Parts installed in the aircraft.
	inspectionReport. This should have a Date input parameter and an Array<Part*> output parameter.
	Iterate over all Parts installed on the plane. Use the inspection function to determine if an inspection
	is required. If an inspection is required on a Part, add that Part to the supplied output Array.
	
File Airline.cc

		getAircraft(const string&) get aircraft with matching reg
		getPart(const string&) get aircraft with matching name
		addPart(const string& part, int fh_inspect, int it_inspect) function. this function adds a part
		Make an addAircraft function. This function should take a string type and a string registration as
	arguments. It should use these arguments to make a new Aircraft object and add it to the appropriate
	Array.
		takeFlight function that accepts a string reg and an int hours as arguments. It should
	retrieve the Aircraft with the given registration (if it exists) and have it takeFlight for the given
	number of hours. If the Aircraft does not exist, print out an error message.
	Make a printAircraft and printParts method. These should print all the Aircraft and all the Parts
	in the Airline respectively.
	n inspectionReport function. This should take as arguments a string reg and a Date&. Find
	the Aircraft with the given registration and print out (to cout)
	install function that takes two strings and a Date& as arguments. The first string is
	an Aircraft registration and the second string is a Part name. If there is a an Aircraft with the
	given registration and a Part with the given name in the Airline, install that Part into the Aircraft



	
		
