#include "Aircraft.h"

Aircraft::Aircraft(const string& t,const string& reg){
  type =t;
  registration = reg;
  int flighthours = 0;
}

Aircraft::~Aircraft(){
  for(int i = 0; i<parts.getSize(); i++){
    delete[] parts[i];
  }
  parts.~Array();

}

string Aircraft::getRegistration() const{
  return registration;
}

void Aircraft::install(Part* p, Date& d){
  p->install(d);
  parts.add(p);
}

void Aircraft::takeFlight(int h){
  flighthours += h;
  for(int i = 0; i<parts.getSize(); i++){
    parts[i]->addFlightHours(h);
  }

}

void Aircraft::inspectionReport(Date& d, Array<Part*> arr){
  for(int i = 0; i<parts.getSize(); i++){
  if(parts[i]->inspection(d)){
    arr.add(parts[i]);
  }
  }
}

ostream& operator<<(ostream& ost, const Aircraft& a){
  ost<<a.type<<" reg: "<<a.getRegistration()<<" flight hours"<< a.flighthours<<endl;
  return ost;
}
