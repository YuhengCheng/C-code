#ifndef AIRCRAFT_H
#define AIRCRAFT_H

#include "Array.h"
#include "Part.h"

class Aircraft{
public:
  friend ostream& operator<<(ostream&, const Aircraft&);
  Aircraft(const string&,const string&);
  ~Aircraft();
  string getRegistration() const;
  void install(Part*, Date&);
  void takeFlight(int);
  void inspectionReport(Date&, Array<Part*>);

private:
  string type;
  string registration;
  int flighthours;
  Array<Part*> parts;
};

#endif
